package com.kafkaprodect.controller;
import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kafkaprodect.config.ApplicationConfiguration;
import com.kafkaprodect.dao.DeptDao;
import com.kafkaprodect.entity.Dept;
import com.kafkaprodect.kafkaprodect.kafakaprodect;
import com.kafkaprodect.service.DeptService;

@RestController
@RequestMapping(value="/main")
public class DeptController {
//	@Autowired
//	private kafakaprodect kafkaProducer;
	@Autowired
	private DeptService deptService;
	@Autowired
	private DeptDao deptDao;
	
	@Autowired
	ApplicationConfiguration app;
	
	
	//PostMapping也是一个组合注解,是@RequestMapping(method = RequestMethod.POST)的缩写。
	@RequestMapping(value = "/findbyid", method = RequestMethod.GET)
    //public List<Dept> findById(String id)
    public Dept findById(@RequestParam(value = "id", required = true) int id)
			throws IOException  {
		System.out.println("数据开始传入kafka");	
		Dept result = deptDao.findById(id);
		//将java对象装换成json
	//	  ObjectMapper om = new ObjectMapper();	  
		//  String jsonResult = om.writeValueAsString(result);
		  
		//  kafkaProducer.send("KAFKA_TESTZYR",jsonResult);		
		
		 kafakaprodect.sendMessage(result.toString(), app.getServers(), app.getTopicName());
		return deptService.findById(id);		
	}
	
	
//	 @PostMapping("/user")
//	    public boolean sendKafka(@RequestBody Dept dept) {
//	        return kafakaprodect.sendMessage(dept.toString(), app.getServers(), app.getTopicName());
//	    }
	
	
	
}



