package com.kafkaprodect.serviceimpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.kafkaprodect.dao.DeptDao;
import com.kafkaprodect.entity.Dept;
import com.kafkaprodect.service.DeptService;
@Service
public class DeptResultImpl implements DeptService{
	@Autowired
	private DeptDao deptDao;
	  @Override
	    public Dept findById(int id) { 
		   return deptDao.findById(id);
	       	    }
	 
}
