package com.kafkaprodect.service;

import java.util.List;

import com.kafkaprodect.entity.Dept;

public interface DeptService {
	Dept findById(int id);
}
