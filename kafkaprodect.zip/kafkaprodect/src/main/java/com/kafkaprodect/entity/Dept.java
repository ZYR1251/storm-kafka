package com.kafkaprodect.entity;

import java.io.Serializable;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONType;


@JSONType(orders = {"id","age","name"})
public class Dept {


private int id;
	private Integer age;
	private String name;
	
	 public Dept() {
	 }
	 
	 public Dept(int id, Integer age ,String name) {
			super();
			this.id = id;
			this.name = name;
			this.age = age;
	}
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	public String toString() {
		return JSON.toJSONString(this);
	}
}
