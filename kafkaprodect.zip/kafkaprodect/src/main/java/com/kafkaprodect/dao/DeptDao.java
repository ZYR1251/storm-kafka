package com.kafkaprodect.dao;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import com.kafkaprodect.entity.Dept;

@Mapper
public interface DeptDao {
	@Select("SELECT * FROM dept where id=#{id}")
	//list集合对象装换为json字符串
	Dept findById(int id);
}
